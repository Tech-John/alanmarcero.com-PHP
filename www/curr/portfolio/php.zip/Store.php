<?php

class Store {
	
	var $db;
	var $smarty;
	var $user;
	var $sendMail;
	
	var $content;
	
	function Store() {
		$this->db = &$GLOBALS['db'];
		$this->smarty = &$GLOBALS['smarty'];
		$this->user = new User(); # user object for obtaining cart information
		$this->sendMail = &$GLOBALS['sendMail'];
			
		if($this->user->url_parameters['add_to_cart']) 
			$this->add_to_cart($this->user->url_parameters['item_id'], $this->user->url_parameters['price']);
		elseif($this->user->url_parameters['remove_from_cart']) 
			$this->remove_from_cart($this->user->url_parameters['item_id']);
		elseif($this->user->url_parameters['free_purchase'])
			$this->free_purchase($this->user->url_parameters['email']);
		elseif($this->user->url_parameters['page'] == 'about')
			$this->show_about();
		else
			$this->show_store();
		
		# finally output all our content
		$this->user->echo_template($this->content);
	}
	
	# returns the subtotal as a float of the User's cart subtotal
	function calculate_subtotal() {
		$subtotal = 0.00;
		foreach($_SESSION['cart'] as $item)
			$subtotal += $item['price'];
			
		return $subtotal;
	}
	
	# adds the input item_id to the User's sesstion cart at the input price
	function add_to_cart($item_id, $price) {
		# don't add it if the item is already in the cart, just change the price
		$add_item = true;
		
		# go through the user's cart and see if the item is already in the cart
		for($i=0; $i < count($_SESSION['cart']); $i++) {
			if($_SESSION['cart'][$i]['item_id'] == $item_id) {
				$_SESSION['cart'][$i]['price'] = $price; # update the price
				$add_item = false; # the item is already in the cart, don't add another copy
			}
		}
		
		# our item object
		$item = array("item_id" => $item_id, "price" => $price);
		
		# if we're adding the item to the cart, do it here
		# the price was updated above if we're NOT adding the item to the cart
		if($add_item) {
			array_push($_SESSION['cart'], $item);
		}
		$this->show_cart();
	}
	
	# removes the input item id from the User's session cart
	function remove_from_cart($item_id) {
		# new cart object, to replace the current cart once we're done
		$new_cart = array();
		
		# go through our c art and add every item that is NOT the input item id
		for($i=0; $i < count($_SESSION['cart']); $i++) {
			if($_SESSION['cart'][$i]['item_id'] != $item_id) {
				array_push($new_cart, $_SESSION['cart'][$i]);
			}
		}
		
		# replace the old cart with the new cart
		$_SESSION['cart'] = $new_cart;
		
		# send the user to the cart view screen
		$this->show_cart();
	}
	
	# purchases all the items in the user's cart and associates those items with the input email address
	function free_purchase($email) {
		
		# create a PHP array cart out of the session cart
		# and then purchase every item in their cart
		$cart = array();
		foreach($_SESSION['cart'] as $item) {
			$result = $this->db->getRow('select * from store_entries where id = ' . $item['item_id']);
			$result['price'] = $item['price'];
			array_push($cart, $result);
			
			# make sure we got an email, and then purchase the item
			if($email) $this->user->purchase_item($email, $item['item_id']);
		}
		
		# get the user's password to include that info in the email
		if($email) $password = $this->db->getOne("select password from customers where email = '" . $email . "'");
		
		# send the purchase confirmation email, one email for their entire cart
		if($email) $this->sendMail->purchase_confirm($cart, $email, $password, true);
		
		# assign info to show the user what they purchased
		$this->smarty->assign('cart', $cart);
		$this->smarty->assign('subtotal', $this->calculate_subtotal());
		$this->smarty->assign('email', $email);
		if($email) $_SESSION['email'] = $email;
		if($email) $_SESSION['cart'] = null;
		
		# send them to the purchase confirmation screen
		$this->content = $this->smarty->fetch(PATH_TEMPLATES . 'free_purchase.html');
	}
	
	# the default page when a user goes to alanmarcero.com
	function show_store() {
		$items = $this->db->getAll('select * from store_entries order by display_position');
		$this->smarty->assign('items', $items);
		$this->content = $this->smarty->fetch(PATH_TEMPLATES . 'store.html');
	}
	
	# shows the about section template
	function show_about() {
		$this->content = $this->smarty->fetch(PATH_TEMPLATES . 'about.html');
	}
	
	# shows the user's cart
	function show_cart($free_purchase = false) {
		# turn the session cart into a PHP cart with the info we need from the DB
		$cart = array();
		foreach($_SESSION['cart'] as $item) {
			$result = $this->db->getRow('select * from store_entries where id = ' . $item['item_id']);
			$result['price'] = $item['price'];
			array_push($cart, $result);
		}
		
		# assign info the show the user what is in their cart
		$this->smarty->assign('cart', $cart);
		$this->smarty->assign('subtotal', $this->calculate_subtotal());
		$this->smarty->assign('paypal_test', PAYPAL_TEST);
		
		# if we're in dev mode, assign the email to send PayPal to the sandbox email
		# there is a button to proceed to paypal from the cart view
		if(PAYPAL_TEST)
			$this->smarty->assign('admin_email', PAYPAL_TEST_EMAIL);
		else
			$this->smarty->assign('admin_email', ADMIN_EMAIL);
		
		# show the cart
		$this->content = $this->smarty->fetch(PATH_TEMPLATES . 'cart.html');
	}
}
?>