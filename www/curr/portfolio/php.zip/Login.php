<?php

class Login {
	
	var $db;
	var $smarty;
	var $user;
	var $sendMail;
	
	var $content;
	var $is_admin;
	
	function Login() {
		$this->db = &$GLOBALS['db'];
		$this->smarty = &$GLOBALS['smarty'];
		$this->user = new User();
		$this->sendMail = &$GLOBALS['sendMail'];
		
		if($this->user->url_parameters['retrieve_pw'] || $this->user->url_parameters['retrieve_pw_email'])
			$this->retrieve_pw($this->user->url_parameters['retrieve_pw_email']);
		elseif(!isset($_SESSION['email'])) {
			# the session email is not set so they are not logged in, attempt to log them in
			if($this->user->url_parameters['authorize']) {
				
				# see if the user is an admin
				$this->is_admin = $this->user->is_admin($this->user->url_parameters['email']);
				
				# authorize the user as either admin or customer
				$authorized = $this->authorize($this->user->url_parameters['email'], $this->user->url_parameters['password']);
				
				# the authorization failed
				if(!$authorized)
					$this->show_login_form(true);
				else { 
					# create session and redirect
					$_SESSION['email'] = $this->user->url_parameters['email'];
					if($this->is_admin)
						header("Location: admin.php");
					else
						header("Location: customers.php");
				}
			} else {
				$this->show_login_form();
			}
		} else
			header("Location: customers.php"); # they're already logged in
			
		$this->user->echo_template($this->content);
	}
	
	# shows the login template
	function show_login_form($login_failed = false) {
		$this->smarty->assign('login_failed', $login_failed);
		$this->content = $this->smarty->fetch(PATH_TEMPLATES . "login.html");
	}
	
	# authorizes the input email and password
	function authorize($email, $password) {
		
		# verify the input email and password in either the admin table or the customers table
		if($this->is_admin)
			$query = "select email from administrators where email = '{$email}' and password = md5('{$password}')";
		else
			$query = "select email from customers where email = '{$email}' and password = '{$password}'";
		$result = $this->db->getOne($query);
		
		# if we got a result, return true, otherwise return false
		if($result)
			return true;
		else
			return false;
	}
	
	# sends the user's password to the input email address IF we have that email address on file
	function retrieve_pw($email) {
		$message = '';
		if($email) {
		
			# check to be sure we have that user's email address on file
			$password = $this->db->getOne("select password from customers where email = '{$email}'");
			if($password != '') {
				# we have it, send the info
				$this->sendMail->account_information($email, $password);
				$message = "Your login and password has been sent to {$email}.";
			}
			else
				# we don't have it, fail
				$message = "The email you entered, {$email}, is not associated with AlanMarcero.com.";
		} else {
			# if they did not enter anything
			$message = "Please enter your email address.  This is typically the same address you have associated with PayPal.";
		}
		
		$this->smarty->assign('message', $message);
		$this->content = $this->smarty->fetch(PATH_TEMPLATES . "retrieve_pw.html");	
	}
	
}
?>