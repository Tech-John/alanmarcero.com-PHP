<?php

require_once('includes/globals.php');
require_once(PATH_LIBRARY . 'User.php');
require_once(PATH_LIBRARY . 'Store.php');

# create our controller that also echos the template
new Store;
?>