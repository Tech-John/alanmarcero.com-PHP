module BlogHelper
end