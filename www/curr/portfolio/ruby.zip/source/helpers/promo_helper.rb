module PromoHelper
end