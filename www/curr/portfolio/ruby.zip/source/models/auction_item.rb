class AuctionItem < ActiveRecord::Base
	belongs_to :store_entry
end