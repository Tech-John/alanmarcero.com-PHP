class BlogEntry < ActiveRecord::Base
	has_many :blog_entry_comments, :order => "id DESC", :dependent => :destroy
	
	validates_presence_of :heading, :content
	
	def self.all_columns
		self.content_columns.find_all do |d|
			!d.name.match /(_at|_on|position|lock_version|_id|password_hash)$/
		end
	end
	
	def self.conditions_by_like(value, *columns)
		columns = self.all_columns if columns.size==0
		columns = columns[0] if columns[0].kind_of?(Array)
		conditions = columns.map {|c|
		c = c.name if c.kind_of? ActiveRecord::ConnectionAdapters::Column
		"`#{c}` LIKE " + ActiveRecord::Base.connection.quote("%#{value}%")
		}.join(" OR ")
	end
	
end