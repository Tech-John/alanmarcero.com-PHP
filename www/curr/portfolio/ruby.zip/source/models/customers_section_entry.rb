class CustomersSectionEntry < ActiveRecord::Base
	validates_presence_of :heading, :content
end