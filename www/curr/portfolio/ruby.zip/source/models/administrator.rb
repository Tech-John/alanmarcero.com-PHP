require 'digest/sha1'
class Administrator < ActiveRecord::Base
	def self.authenticate(email, password)
		user = self.find_by_email(email)
		if user
			expected_password = encrypted_password(password, user.salt)
			if user.hashed_password != expected_password
				user = nil
			end
		end
		user
	end
	
	def password
		@password
	end
	
	def password=(pwd)
		@password = pwd
		create_new_salt
		self.hashed_password = Administrator.encrypted_password(self.password, self.salt)
	end
	
	private
	
	def self.encrypted_password(password, salt)
		string_to_hash = password + "bobbly" + salt
		Digest::SHA1.hexdigest(string_to_hash)
	end

	def create_new_salt
		self.salt = self.object_id.to_s + rand.to_s
	end
end