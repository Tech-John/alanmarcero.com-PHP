class ApplicationMailer < ActionMailer::Base
	def purchase_confirm(order, customer)
		@subject = "Your AlanMarcero.com/AM-Sounds.com Purchase"
		@recipients = customer.email
		@from = Administrator.find(:first).email
		@sent_on = Time.now
		@body["order"] = order
		@body["customer"] = customer
		@content_type = "text/html"
	end
	
	def account_information(customer)
		@subject = "Your AlanMarcero.com/AM-Sounds.com Account Information"
		@recipients = customer.email
		@from = Administrator.find(:first).email
		@sent_on = Time.now
		@body["customer"] = customer
		@content_type = "text/html"
	end
	
	def opt_in(email)
		@subject = "AlanMarcero.com/AM-Sounds.com Product Notification Opt-In"
		@recipients = email
		@from = Administrator.find(:first).email
		@send_on = Time.now
		@body["email"] = email
		@content_type = "text/html"
	end
	
	def opt_out(email)
		@subject = "AlanMarcero.com/AM-Sounds.com Product Notification Opt-Out"
		@recipients = email
		@from = Administrator.find(:first).email
		@send_on = Time.now
		@body["email"] = email
		@content_type = "text/html"
	end
	
	def request_additional_downloads(purchased_item)
		@subject = "Additional Downloads Have Been Requested"
		@recipients = Administrator.find(:first).email
		@from = purchased_item.customer.email
		@send_on = Time.now
		@body["purchased_item"] = purchased_item
		@content_type = "text/html"
	end
	
	def additional_downloads_granted(purchased_item)
		@subject = "Additional Downloads Have Been Granted"
		@recipients = purchased_item.customer.email
		@from = Administrator.find(:first).email
		@send_on = Time.now
		@body["purchased_item"] = purchased_item
		@content_type = "text/html"
	end 
	
	def account_information_altered(customer, email)
		@subject = "Your AlanMarcero.com/AM-Sounds.com Account Information"
		@recipients = email
		@from = Administrator.find(:first).email
		@sent_on = Time.now
		@body["customer"] = customer
		@body["admin_email"] = Administrator.find(:first).email
		@content_type = "text/html"
	end
	
	def promotional_email(subject, content, recipient)
		@subject = subject
		@recipients = recipient
		@from = Administrator.find(:first).email
		@sent_on = Time.now
		@body["recipient"] = recipient
		@body["content"] = content
		@content_type = "text/html"
	end
end