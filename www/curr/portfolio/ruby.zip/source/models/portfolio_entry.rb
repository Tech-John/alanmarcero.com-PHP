class PortfolioEntry < ActiveRecord::Base
	validates_presence_of :image_url, :content, :display_position
	validates_numericality_of :display_position
	validates_uniqueness_of :display_position
end