class About < ActiveRecord::Base
	validates_presence_of :heading, :content, :display_position
	validates_numericality_of :display_position
end