class Cart
	attr_reader :items
	
	def initialize
		@items = []
	end
	
	def add_product(product)
		current_item = @items.find {|item| item.product == product }
		if !current_item
			if product.price != 0.00
				current_item = CartItem.new(product)
				@items << current_item
			end
		end
		current_item
	end
	
	def total_price
		@items.sum { |item| item.price }
	end
	
	def remove_product(product)
		current_item = @items.find {|item| item.product == product }
		if current_item
			@items.delete current_item
		end
	end
	
	def total_items
		@items.length
	end  
end