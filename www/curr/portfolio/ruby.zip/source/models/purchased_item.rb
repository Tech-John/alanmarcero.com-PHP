class PurchasedItem < ActiveRecord::Base
	validates_presence_of :customer_id, :store_entry_id
	belongs_to :customer
	belongs_to :store_entry
	
	def validate_on_create
		customer = Customer.find(customer_id)
		if customer.purchased_items.find_by_store_entry_id(store_entry_id) # .exists?
			errors.add_to_bass("Customer has already purchased item")
		end
	end
end