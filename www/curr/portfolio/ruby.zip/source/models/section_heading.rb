class SectionHeading < ActiveRecord::Base
	validates_presence_of :content, :section
end