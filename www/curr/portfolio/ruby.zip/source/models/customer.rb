class Customer < ActiveRecord::Base
	validates_presence_of :email, :password
	validates_uniqueness_of :email
	
	has_many :purchased_items, :dependent => :destroy
	
	def self.authenticate(email, password)
		if customer = self.find_by_email(email)
			if customer.password != password
				customer = nil
			end
		end
		customer
	end
	
	def self.get_customer(email)
		if Customer.exists?(:email => email)
			customer = Customer.find_by_email(email)
		else
			customer = create_customer(email)
		end
		customer
	end
	
	def self.create_customer(email)
		if customer = Customer.new(:email => email, :password => random_password)
			if customer.save
				PromotionalEmail.create(:email => email)
				ApplicationMailer.deliver_account_information(customer)
			end
		end
		customer
	end
	
	def self.reset_password(email)
		customer = find_by_email(email)
		Customer.update(customer.id, :password => random_password)
		ApplicationMailer.deliver_account_information(Customer.find_by_email(email))
	end
	
	def self.request_item(id, email)
		requested_item = Customer.find_by_email(email).purchased_items.find_by_store_entry_id(id)
		if requested_item
			if requested_item.download_limit > 0
				requested_item.download_limit -= 1
				requested_item.save
				return_value = true
			end
		end
		return_value
	end
	
	def self.random_password
		chars = ("a".."n").to_a + ("p".."z").to_a + ("A".."N").to_a + 
			("P".."Z").to_a + ("1".."9").to_a + ("1".."9").to_a
		newpass = ""
		1.upto(6) { newpass << chars[rand(chars.size-1)] }
		newpass
	end
end