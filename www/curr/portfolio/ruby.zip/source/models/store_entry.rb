class StoreEntry < ActiveRecord::Base
	validates_presence_of :image_url, :name, :content, :audio_demo, :price, :store, :display_position
	validates_numericality_of :display_position
end