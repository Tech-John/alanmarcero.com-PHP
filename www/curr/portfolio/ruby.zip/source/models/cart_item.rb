class CartItem
attr_reader :product

	def initialize(product)
		@product = product
	end
	
	def name
		@product.name
	end
	
	def price
		@product.price
	end
	
	def id
		@product.id
	end
end