class PromotionalEmail < ActiveRecord::Base
	validates_presence_of :email
	validates_uniqueness_of :email
	validates_format_of :email, :with =>%r{^((?:(?:(?:[a-zA-Z0-9][\.\-\+_!#%&\*|~=/^]?)*)[a-zA-Z0-9])+)\@((?:(?:(?:[a-zA-Z0-9][\.\-_]?){0,62})[a-zA-Z0-9])+)\.([a-zA-Z0-9]{2,6})$}
end
