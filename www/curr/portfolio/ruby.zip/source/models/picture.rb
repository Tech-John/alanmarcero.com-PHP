class Picture < ActiveRecord::Base
	validates_presence_of :thumb_url, :description, :display_position, :full_size_url
	validates_numericality_of :display_position
end