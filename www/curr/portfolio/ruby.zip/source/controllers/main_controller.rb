class MainController < ApplicationController
	before_filter :init
	
	def index
		redirect_to :controller => :blog
	end

	def portfolio
		get_heading_for "portfolio"
		@entries = PortfolioEntry.find(:all, :order => "display_position")
	end
	
	def abouts
		@entries = About.find(:all, :order => "display_position")
	end
	
	def legal
		@entry = SingleEntrySection.find_by_section("legal")
	end
	
	def about_this_website
		@entry = SingleEntrySection.find_by_section("about_this_website")
		render :action => :legal
	end
end