class AdminLoginController < ApplicationController

	def index
		@dont_show_nav = true
		session[:admin_email] = nil
		if request.post?
			user = Administrator.authenticate(params[:email], params[:password])
			if user
				session[:admin_email] = user.email
				uri = session[:original_uri]
				session[:original_uri] = nil
				redirect_to(uri || { :controller => "admin", :action => "index" })
			else
				flash[:notice] = "Invalid user/password combination."
			end
		end
		render :layout => 'admin' unless user
	end
  
	def logout
		session[:admin_email] = nil
		flash[:notice] = "Logged out"
		redirect_to(:action => "index")
	end
end