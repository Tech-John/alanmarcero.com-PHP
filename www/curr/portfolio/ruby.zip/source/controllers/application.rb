class ApplicationController < ActionController::Base
	session :session_key => '_alan_session_id'

	def initialize
		@paypal_test = false
		@admin_email = Administrator.find(:first).email
	end
	
	def redirect_with_message(controller, action, message)
		flash[:notice] = message
		redirect_to :controller => controller, :action => action
	end

	def init
		@cart = find_cart
		@pictures = Picture.find(:all, :order => "display_position")
		@customer_email = session[:customer_email]
	end
	
	def find_cart
		session[:cart] ||= Cart.new
	end

	def get_heading_for(section)
		@heading = SectionHeading.find_by_section(section)
	end
	
	def has_purchased_items?(email)
		customer = Customer.find_by_email(email)
		if customer
			if customer.purchased_items.length > 0
				true
			else
				false
			end
		end
	end
	
	def logged_in?
		session[:customer_email]
	end
end
