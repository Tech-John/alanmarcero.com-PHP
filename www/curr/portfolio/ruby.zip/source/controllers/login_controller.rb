class LoginController < ApplicationController
	before_filter :init
	
	def index
		if request.post?
			message = ""
			if customer = Customer.authenticate(params[:email], params[:password])
				session[:customer_email] = customer.email
				flash[:notice] = "Thank you for logging in with email " + customer.email + "."
			else
				flash[:notice] = "Invalid password for email " + params[:email] + "."
			end
		end
    
    	if logged_in?
			redirect_to session[:original_uri] || { :controller => :main, :action => :blog }
    	end
	end

	def retreive_password
		get_heading_for "retreive_password"
		if request.post?
			if customer = Customer.find_by_email(params[:email])
				ApplicationMailer.deliver_account_information(customer)
				redirect_with_message "blog", "index", 
					"Your password has been emailed to your registered email address."
			else
				redirect_with_message "login", "retreive_password", 
					params[:email].to_s + " is not a registered email address."
			end
		end
	end
	
	def logout
		session[:customer_email] = nil
		redirect_with_message "blog", "index", "Successfully logged out."
	end
end