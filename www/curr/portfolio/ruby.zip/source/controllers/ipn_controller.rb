class IpnController < ApplicationController
	def index
		if ipn_confirm 
			if Administrator.exists?(:email => params[:receiver_email]) 
				
				all_items = get_items
				total_price = 0.00
				
				for item in all_items
					total_price += item.price
				end
				
				if total_price == params[:payment_gross].to_f
					customer = Customer.get_customer(params[:payer_email])
					
					for item in all_items
						success = customer.purchased_items.create(
							:store_entry_id => item.id, :download_limit => 5)
					end
					ApplicationMailer.deliver_purchase_confirm(all_items, customer) if success
				end 
			end
		end
	end

	private

	def ipn_confirm
		@raw = request.raw_post
		uri = URI.parse("http://www.paypal.com/cgi-bin/webscr" )
		uri = URI.parse("http://www.sandbox.paypal.com/cgi-bin/webscr" ) if @paypal_test
		status = nil
		Net::HTTP.start(uri.host, uri.port) do |request|
			status = request.post(uri.path, @raw + "&cmd=_notify-validate" ).body if @raw
		end
		logger.debug "status = '#{status}'"
		status == "VERIFIED"
	end
	
	def get_items
		all_items = Array.new
		
		if params[:for_auction] == "true"
		
			1.upto(params[:num_cart_items].to_i) do |i|
				item_name = "item_name" + i.to_s
				item=AuctionItem.find_by_auction_title(params[item_name.to_sym]).store_entry
				all_items.push(item)
			end
		else
			1.upto(params[:num_cart_items].to_i) do |i|
				item_number = "item_number" + i.to_s
				item = StoreEntry.find(params[item_number.to_sym])
				all_items.push(item)
			end
		end
		all_items
	end
end