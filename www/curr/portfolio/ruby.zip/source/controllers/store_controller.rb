class StoreController < ApplicationController
	before_filter :init
	
	def index
		get_heading_for "discography"
		@entries = StoreEntry.find_all_by_store("discography", :order => "display_position")
	end
	
	def sounds
		get_heading_for "sounds"
		@entries = StoreEntry.find_all_by_store("sounds", :order => "display_position")
		render :action => :index
	end
	
	def check_out
		redirect_with_message "blog", "index", 
			"ERROR: Your cart is currently empty." if @cart.items.length == 0
		get_heading_for "check_out"
		@checking_out = true 
	end
	
	def remove_from_cart
		product = StoreEntry.find(params[:id])
		@current_item = @cart.remove_product(product)
		get_heading_for "blog"
		redirect_to :action => 'blog' unless request.xhr?
	end
	
	def empty_cart
		session[:cart] = nil 
		redirect_to :action => "blog" unless request.xhr?
	end
	
	def add_to_cart
		product = StoreEntry.find(params[:id]) 
		if @cart.total_items == 0
			@new_cart = true
		else 
			@new_cart = false
		end
		
		@current_item = @cart.add_product(product)
		@id = params[:id]
		
		unless request.xhr?
			if product.store == "discography"
				redirect_to :action => "discography"
			else
				redirect_to :action => "sounds"
			end
		end
	end

	def completed_purchase
		@purchase_complete = true
		id_token = "removed for security"
		id_token = "removed for security" if @paypal_test
		tx_token = "dummy" 
		tx_token = params[:tx] if params[:tx] 
		
		uri = URI.parse("http://www.paypal.com/cgi-bin/webscr")
		uri = URI.parse("http://www.sandbox.paypal.com/cgi-bin/webscr") if @paypal_test
		postData="at=" + id_token + "&tx=" + tx_token + "&cmd=_notify-synch"
		responseString = nil
		
		Net::HTTP.start(uri.host, uri.port) do |request|
			responseString = request.post(uri.path, postData).body
		end
		
		responseArray = responseString.split()
		
		success = false 
		if responseArray[0] == "SUCCESS"
			session[:cart] = nil 
			@total_paid = 0.00
			@items = Array.new
			@payer_email = String.new
		
			for line in responseArray
				array = line.split("=")
				case 
					when array[0] == "mc_gross"
						@total_paid = array[1].to_f
		
					when array[0].first(11) == "item_number"
						@items.push(StoreEntry.find(array[1]))       
		
					when array[0].first(11) == "payer_email"
						@payer_email = array[1]
						@payer_email = @payer_email.sub("%40", "@")
				end 
			end 
			total_price = 0.00
			for item in @items
				total_price += item.price
			end
		
			if @total_paid == total_price
				success = true
				session[:customer_email] = @payer_email
			end
		end
		redirect_with_message "blog", "index", 
			"There was an error processing your request.  
			Please contact me at " + @admin_email unless success
	end

	def process_payment
	end
end