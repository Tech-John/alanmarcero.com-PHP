class PromoController < ApplicationController
	before_filter :init
	
	def index
		if params[:email]
			new_email = PromotionalEmail.new(:email => params[:email])
			if new_email.save
				ApplicationMailer.deliver_opt_in(params[:email])
				@success = true
			end
	
			unless request.xhr?
				message = ""
				if @success
					message = "Thank you for subscribing with email " + new_email.email + "."
				else
					message = "Error: " + new_email.email + 
						" is not valid or already subscribed.  Please try again."
				end
				redirect_with_message "blog", "index", message
			end
		else
			redirect_to :controller => "blog"
		end
	end

	def opt_out
		get_heading_for "opt_out"
		if params[:email]
			email = PromotionalEmail.find_by_email(params[:email])
			if email
				email.destroy
				ApplicationMailer.deliver_opt_out(params[:email])
				redirect_with_message "blog", "index", params[:email].to_s + 
					" will no longer recieve new product notifications."
			else
				redirect_with_message "blog", "index", "Invalid email address."
			end
		end
	end
end
