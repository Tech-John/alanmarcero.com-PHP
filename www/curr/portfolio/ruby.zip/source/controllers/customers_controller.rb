class CustomersController < ApplicationController
	before_filter :check_login, :init

	def index
		if has_purchased_items?(session[:customer_email])
			@entries = CustomersSectionEntry.find(:all, :order => "id desc")
			get_heading_for "customers_section"
		else
			redirect_with_message "blog", "index", 
				"You must first purchase an item to enter the Customer's Section."
		end
	end

	def alter_info
		get_heading_for "alter_info"
		if request.post?
			if customer = Customer.authenticate(session[:customer_email].to_s, params[:password])
				old_email = customer.email
				if customer = Customer.update(customer.id, {:email => params[:email].to_s })
					PromotionalEmail.find_by_email(session[:customer_email].to_s).destroy
					PromotionalEmail.create(:email => params[:email])
					session[:customer_email] = params[:email]
					ApplicationMailer.deliver_account_information_altered(customer, old_email)
					ApplicationMailer.deliver_account_information_altered(customer, params[:email]) unless old_email == params[:email]
					redirect_with_message "customers", "index", 
						"Your account information has been updated."
				else
					redirect_with_message "main", "alter_info", 
						"There was an error updating your account information. Please try again."
				end
			else
				redirect_with_message "main", "alter_info", 
					"Your current password was not entered correctly."
			end 
		end
	end

	def download_item
		if has_purchased_items?(session[:customer_email])
			if Customer.request_item(params[:id], session[:customer_email])
				lookup = StoreEntry.find_by_id(params[:id])
				redirect_to lookup.full_item_url
			else
				redirect_with_message "customers", "index", 
					"You have no more downloads available for that item.  
					Please request additional downloads."
			end
		else
			redirect_with_message "blog", "index", 
				"You must first purchase an item to enter the Customer's Section."
		end
	end

	def purchased_items
		if has_purchased_items?(session[:customer_email])
			@admin_email = Administrator.find(:first).email
			get_heading_for "purchased_items"
			@purchased_items = Customer.find_by_email(session[:customer_email]).purchased_items
		else
			redirect_with_message "blog", "index", 
				"You must first purchase an item to enter the Customer's Section."
		end
	end

	def request_additional_downloads
		if params[:id]
			item = PurchasedItem.find(params[:id])
			ApplicationMailer.deliver_request_additional_downloads(item) unless !item
			redirect_with_message "customers", "purchased_items", 
				"An email has been sent to the administrator requesting additional 
				downloads for " + item.store_entry.name + ".<br /><br />
				You will be notified by email when the admin has approved your request."
		else
			redirect_to :action => :blog
		end
	end

	def reset_password
		Customer.reset_password(session[:customer_email])
		redirect_with_message "customers", "index", 
			"Your new password has been emailed to you."
	end

	private
	
	def check_login
		if !session[:customer_email]
			session[:original_uri] = request.request_uri
			redirect_with_message "login", "index", 
				"Please login with your customer account information."
		else
			if !has_purchased_items?(session[:customer_email])
				redirect_with_message "blog", "index",
					"You must have purchased an item to enter the Customer's Section."
			end
		end
	end
end