class AdminController < ApplicationController
	before_filter :authorize
  
	def index
		@model = BlogEntry
		@model = params[:model].constantize if params[:model]
		@entries = @model.find(:all, :order => "id desc")
	end
  
	def create_entry
		@model = params[:model].constantize
		@submit_action = "create_entry" 
		if request.post?
			@entry = @model.new(params[:entry])
			if @entry.save
				flash[:notice] = 'Entry was successfully created.'
				redirect_to :action => :index, :model => params[:model]
			end
		end
	end
  
	def destroy_entry
		params[:model].constantize.find(params[:id]).destroy
		flash[:notice] = "The entry has been destoyed."
		redirect_to :action => :index, :model => params[:model]
	end

	def edit_entry
		@model = params[:model].constantize
		@entry = @model.find(params[:id])
		if request.post? 
			if @entry.update_attributes(params[:entry])
				success = true
				flash[:notice] = "The entry has been edited."
				redirect_to :action => :index, :model => params[:model]
			end
		else
			@submit_action = "edit_entry" 
		end
		render :action => :create_entry unless success
	end

	def manual_sales_entry
		@items_for_sale = StoreEntry.find(:all, :conditions => "price > 0.00")
		
		if request.post?
			customer = Customer.get_customer(params[:email])
			
			order = Array.new 
			
			for item in params[:items]
				customer.purchased_items.create(
					:store_entry_id => item[0], 
					:download_limit => 5) unless item[1] == "0"
				order.push(StoreEntry.find(item[0])) unless item[1] == "0"
			end
			ApplicationMailer.deliver_purchase_confirm(order, customer)
			flash[:notice] = "Items processed for " + params[:email].to_s
			params[:email] = nil
		end 
	end

	def customer_info
		if params[:id]
			item = PurchasedItem.find(params[:id])
			item.download_limit = 5
			item.save
			ApplicationMailer.deliver_additional_downloads_granted(item)
			flash[:notice] = "Downloads reset.  Email sent."
		end
		
		if params[:email]
			customer = Customer.find_by_email(params[:email])
			if customer
				@purchased_items = customer.purchased_items
			else
				redirect_with_message "admin", "customer_info", "Invalid email."
			end
		
		end
	end
  
	def send_promotional_email
		if request.post?
			emails = PromotionalEmail.find(:all)
			for email in emails
				ApplicationMailer.deliver_promotional_email(
					params[:subject], params[:content], email.email)
			end
			redirect_with_message "admin", "send_promotional_email", "The Email '" + 
			params[:subject] + "' has been sent to all recipients."
		end
	end

	private
  
	def authorize
		unless Administrator.find_by_email(session[:admin_email])
			session[:original_uri] = request.request_uri
			redirect_to(:controller => "admin_login")
		end
	end
end