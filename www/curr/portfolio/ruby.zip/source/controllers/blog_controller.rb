class BlogController < ApplicationController
	before_filter :init

	def index
		get_heading_for "blog"
		respond_to do |format|
			format.html {
				if params[:id] 
					@entry = BlogEntry.find(params[:id])
				else 
					@entry = BlogEntry.find(:first, :order => "id desc")
				end
			}
			format.xml {
				@entries_feed = BlogEntry.find (:all, 
					:select => "heading,content,created_at,id",
					:limit  => 5,
					:order  =>  "id DESC")
					render :layout => false, :action => "feed.rxml"
			}
		end
	end
	
	def all_blog_entries
		get_heading_for "blog"
		@entries = BlogEntry.find(:all, :order => "id desc")
	end
	
	def create_blog_comment
		comment = BlogEntry.find(params[:id]).blog_entry_comments.create(params[:blog_comment])
		if comment.save
			redirect_with_message "blog", "index", "Thank you for your comment."
		else
			redirect_with_message "blog", "index", "You forgot to comment!"
		end
	end
  
	def search
		@entries = BlogEntry.find(:all, :order => "id desc", 
			:conditions => BlogEntry.conditions_by_like(params[:search]))
		matched_comments = BlogEntryComment.find(:all, :order => "id desc", 
			:conditions => BlogEntryComment.conditions_by_like(params[:search]))
	
		for comment in matched_comments
			found = nil
			insert_at = 0
			i=0; for entry in @entries
				if entry.id == comment.blog_entry_id
					found = true
				elsif entry.id < comment.blog_entry_id 
					insert_at = i - 1 unless i == 0
					break
				end
				i += 1
			end
			@entries.insert(insert_at, comment.blog_entry) unless found
		end
	
		respond_to do |format|
			format.html  { 
				get_heading_for "blog"
				render(:template  => "main/all_blog_entries") 
			}
			format.js { render :partial=>'blog_entry_listing', :layout=> false }
		end
	end
end